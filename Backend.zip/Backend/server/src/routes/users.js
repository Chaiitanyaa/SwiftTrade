const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const redisClient = require("../config/redis");
const router = express.Router();

// Register a new user
router.post("/register", async (req, res) => {
    try {
        const { user_name, password, name } = req.body;

        // Check Redis cache (use a try-catch to avoid Redis failures crashing the app)
        try {
            const cachedUser = await redisClient.get(`user:${user_name}`);
            if (cachedUser) {
                return res.status(400).json({ success: false, error: "User already exists (cached)" });
            }
        } catch (redisError) {
            console.error("Redis Error:", redisError);
        }

        // Query MongoDB for existing user
        const existingUser = await User.findOne({ user_name }).maxTimeMS(3000); // Limit query time
        if (existingUser) {
            try {
                await redisClient.set(`user:${user_name}`, "exists", "EX", 300);
            } catch (redisError) {
                console.error("Redis Set Error:", redisError);
            }
            return res.status(400).json({ success: false, error: "User already exists" });
        }

        // Hash password asynchronously
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ user_name, password: hashedPassword, name });

        // Save user to MongoDB
        await newUser.save();

        return res.status(201).json({ success: true, message: "User registered successfully" });

    } catch (error) {
        console.error("Registration Error:", error);
        return res.status(500).json({ success: false, error: "Server error" });
    }
});

// Login user
router.post("/login", async (req, res) => {
    try {
        const { user_name, password } = req.body;
        const user = await User.findOne({ user_name });

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(400).json({ success: false, error: "Invalid credentials" });
        }

        const token = jwt.sign(
            { id: user._id.toString(), user_name: user.user_name },
            process.env.JWT_SECRET || "your_secret",
            { expiresIn: "1h" }
        );

        user.jwt_token = token;
        await user.save();

        return res.json({ 
            success: true, 
            data: { token }  
        });

    } catch (error) {
        console.error("Login Error:", error);
        return res.status(500).json({ success: false, error: "Server error" });
    }
});

module.exports = router;
