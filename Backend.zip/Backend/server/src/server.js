const app = require("./app");
const connectDB = require("./config/db");

require("dotenv").config(); // Load environment variables

connectDB();

// Increase concurrent requests handled
const server = app.listen(process.env.PORT || 1900, () => {
    console.log(`Server running on port ${server.address().port}`);
    server.keepAliveTimeout = 65000;  // Prevents connections from closing too fast
    server.headersTimeout = 66000;
});