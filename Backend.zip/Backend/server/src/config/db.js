const mongoose = require("mongoose");

mongoose.connect(process.env.MONGO_URI || "mongodb://localhost:27017/mydb", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    maxPoolSize: 50,  // Limit to 50 connections
    socketTimeoutMS: 45000,  // Increase timeout
    serverSelectionTimeoutMS: 5000 // Avoid long waits on unavailable servers
});

const db = mongoose.connection;

db.on("error", (err) => {
    console.error("MongoDB connection error:", err);
});

db.once("open", () => {
    console.log("Connected to MongoDB");
});

module.exports = db;
